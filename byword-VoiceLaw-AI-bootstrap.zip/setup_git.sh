#!/bin/bash

# === Git Identity Setup ===
git config --global user.name "Shaun Muldowney"
git config --global user.email "bywordofmouthcatering@gmail.com"
git config --global credential.helper store

# === Store Token ===
echo "https://Shauny123:<YOUR_GITHUB_PAT>@github.com" > ~/.git-credentials
chmod 600 ~/.git-credentials

# === Git Auto Commit and Push ===
cd "$(dirname "$0")"
git add .
if ! git diff --cached --quiet; then
    git commit -m "🔄 Auto-sync update $(date +'%Y-%m-%d %H:%M:%S')"
    git push origin main && echo "✅ Pushed to GitHub"
else
    echo "🟢 No changes to commit."
fi
