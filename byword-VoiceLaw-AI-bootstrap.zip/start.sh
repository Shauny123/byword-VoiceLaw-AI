#!/bin/bash
echo "🔁 Pulling latest updates..."
git pull origin main

echo "🚀 Starting server..."
uvicorn main:app --host 0.0.0.0 --port 8000
